import os
import sys
import shutil
import subprocess
from pathlib import Path


# ==========================================
# НАСТРОЙКИ ГОРОДСКОЙ СЕТИ
# ==========================================

PROJECT_DIR = Path(__file__).resolve().parent

NETWORK_DIR = PROJECT_DIR / "network"
ROUTES_DIR = PROJECT_DIR / "routes"

NETWORK_FILE = NETWORK_DIR / "city.net.xml"
ROUTES_FILE = ROUTES_DIR / "city.rou.xml"

# Количество перекрёстков по горизонтали и вертикали
GRID_SIZE = 4

# Расстояние между перекрёстками (метры)
ROAD_LENGTH = 250

# Количество полос в каждом направлении
LANES = 2

# Скорость движения (м/с)
MAX_SPEED = 13.89

# Продолжительность генерации автомобилей (сек)
SIMULATION_TIME = 3600

# Средний интервал появления автомобилей (сек)
VEHICLE_PERIOD = 2.0

# Начальное значение генератора случайных чисел
RANDOM_SEED = 42


# ==========================================
# ПОИСК ИНСТРУМЕНТОВ SUMO
# ==========================================

def find_sumo_tool(tool_name):
    """
    Ищет исполняемый файл SUMO.
    Сначала проверяет PATH, затем SUMO_HOME.
    """

    executable = shutil.which(tool_name)

    if executable:
        return executable

    sumo_home = os.environ.get("SUMO_HOME")

    if sumo_home:
        suffix = ".exe" if os.name == "nt" else ""
        candidate = Path(sumo_home) / "bin" / (tool_name + suffix)

        if candidate.exists():
            return str(candidate)

    raise FileNotFoundError(
        f"Не найден инструмент {tool_name}. "
        "Проверьте установку SUMO и переменную SUMO_HOME."
    )


def find_random_trips():
    """Находит официальный скрипт randomTrips.py."""

    sumo_home = os.environ.get("SUMO_HOME")

    if not sumo_home:
        raise EnvironmentError(
            "Не установлена переменная SUMO_HOME."
        )

    script = Path(sumo_home) / "tools" / "randomTrips.py"

    if not script.exists():
        raise FileNotFoundError(
            f"Не найден randomTrips.py: {script}"
        )

    return str(script)


# ==========================================
# СОЗДАНИЕ ПАПОК
# ==========================================

def create_directories():

    NETWORK_DIR.mkdir(parents=True, exist_ok=True)
    ROUTES_DIR.mkdir(parents=True, exist_ok=True)

    (PROJECT_DIR / "results").mkdir(
        parents=True,
        exist_ok=True
    )

    print("[OK] Папки проекта созданы.")


# ==========================================
# ГЕНЕРАЦИЯ ДОРОЖНОЙ СЕТИ
# ==========================================

def generate_network():

    print("\n[1/2] Генерация городской сети...")

    netgenerate = find_sumo_tool("netgenerate")

    command = [
        netgenerate,

        "--grid",

        "--grid.number",
        str(GRID_SIZE),

        "--grid.length",
        str(ROAD_LENGTH),

        "--default.lanenumber",
        str(LANES),

        "--default.speed",
        str(MAX_SPEED),

        "--tls.guess",

        "--tls.default-type",
        "static",

        "--no-turnarounds",
        "true",

        "--output-file",
        str(NETWORK_FILE)
    ]

    subprocess.run(command, check=True)

    print("[OK] Городская сеть создана.")
    print(f"[INFO] Файл: {NETWORK_FILE}")


# ==========================================
# ГЕНЕРАЦИЯ АВТОМОБИЛЕЙ И МАРШРУТОВ
# ==========================================

def generate_routes(seed=RANDOM_SEED, routes_file=ROUTES_FILE):

    routes_file = Path(routes_file)
    routes_file.parent.mkdir(parents=True, exist_ok=True)

    print("\n[2/2] Генерация автомобилей и маршрутов...")
    print(f"[INFO] Seed: {seed}")

    random_trips = find_random_trips()

    command = [
        sys.executable,
        random_trips,

        "--net-file",
        str(NETWORK_FILE),

        "--route-file",
        str(routes_file),

        "--begin",
        "0",

        "--end",
        str(SIMULATION_TIME),

        "--period",
        str(VEHICLE_PERIOD),

        "--seed",
        str(seed),

        "--min-distance",
        str(ROAD_LENGTH),

        "--trip-attributes",
        'departLane="best" departSpeed="max"',

        "--validate"
    ]

    subprocess.run(command, check=True)

    print("[OK] Маршруты созданы.")
    print(f"[INFO] Файл: {routes_file}")


# ==========================================
# ЗАПУСК ПОДГОТОВКИ ПРОЕКТА
# ==========================================

def main():

    print("=" * 55)
    print(" INTELLIGENT CITY TRAFFIC SIMULATION")
    print("=" * 55)

    try:

        create_directories()

        generate_network()

        generate_routes()

        print("\n" + "=" * 55)
        print(" ГОРОД УСПЕШНО СОЗДАН!")
        print("=" * 55)

        print(f"Размер сетки: {GRID_SIZE} x {GRID_SIZE}")
        print(f"Длина дороги: {ROAD_LENGTH} м")
        print(f"Полос на направлении: {LANES}")
        print(f"Время моделирования: {SIMULATION_TIME} сек")
        print(f"Интервал генерации: {VEHICLE_PERIOD} сек")

        print("\nСледующий этап:")
        print("Создание интеллектуальных агентов светофоров.")

    except Exception as error:

        print("\n[ERROR] Ошибка подготовки проекта:")
        print(error)

        sys.exit(1)


if __name__ == "__main__":
    main()