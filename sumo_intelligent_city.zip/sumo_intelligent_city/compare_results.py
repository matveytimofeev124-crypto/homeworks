import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


PROJECT_DIR = Path(__file__).resolve().parent
RESULTS_DIR = PROJECT_DIR / "results"

ADAPTIVE_FILE = RESULTS_DIR / "adaptive_summary.csv"
FIXED_FILE = RESULTS_DIR / "fixed_summary.csv"


def load_summary(file_path):
    """Загружает итоговую статистику из CSV."""

    if not file_path.exists():
        raise FileNotFoundError(
            f"Не найден файл: {file_path}"
        )

    data = {}

    with open(file_path, "r", encoding="utf-8-sig") as file:
        reader = csv.DictReader(file)

        for row in reader:
            data[row["metric"]] = float(row["value"])

    return data


def calculate_improvement(adaptive, fixed):
    """Рассчитывает улучшение относительно фиксированного режима."""

    lower_is_better = [
        "average_queue_length",
        "average_waiting_vehicles",
        "total_waiting_time_vehicle_seconds",
    ]

    results = {}

    for metric in lower_is_better:
        fixed_value = fixed[metric]
        adaptive_value = adaptive[metric]

        if fixed_value != 0:
            improvement = (
                (fixed_value - adaptive_value)
                / fixed_value
                * 100
            )
        else:
            improvement = 0.0

        results[metric] = improvement

    # Для скорости большее значение лучше
    fixed_speed = fixed["average_speed_km_per_hour"]
    adaptive_speed = adaptive["average_speed_km_per_hour"]

    results["average_speed_km_per_hour"] = (
        (adaptive_speed - fixed_speed)
        / fixed_speed
        * 100
        if fixed_speed != 0 else 0.0
    )

    # Для количества прибывших автомобилей большее значение лучше
    fixed_arrived = fixed["arrived_vehicles"]
    adaptive_arrived = adaptive["arrived_vehicles"]

    results["arrived_vehicles"] = (
        (adaptive_arrived - fixed_arrived)
        / fixed_arrived
        * 100
        if fixed_arrived != 0 else 0.0
    )

    return results


def save_comparison_csv(adaptive, fixed, improvements):
    """Сохраняет сравнительную таблицу."""

    output_file = RESULTS_DIR / "comparison.csv"

    metrics = [
        "average_queue_length",
        "average_waiting_vehicles",
        "total_waiting_time_vehicle_seconds",
        "average_speed_km_per_hour",
        "arrived_vehicles",
        "vehicles_at_end",
    ]

    with open(
        output_file,
        "w",
        newline="",
        encoding="utf-8-sig"
    ) as file:

        writer = csv.writer(file)

        writer.writerow([
            "metric",
            "adaptive",
            "fixed",
            "improvement_percent",
        ])

        for metric in metrics:
            writer.writerow([
                metric,
                adaptive.get(metric, 0),
                fixed.get(metric, 0),
                improvements.get(metric, 0),
            ])

    print(f"\nСравнительная таблица сохранена: {output_file}")


def create_comparison_chart(
    adaptive,
    fixed,
    metric,
    title,
    ylabel,
    filename
):
    """Создаёт сравнительный столбчатый график."""

    values = [
        adaptive[metric],
        fixed[metric],
    ]

    labels = [
        "Адаптивное",
        "Фиксированное",
    ]

    plt.figure(figsize=(9, 6))

    bars = plt.bar(labels, values, width=0.5)

    plt.title(title, fontsize=14)
    plt.ylabel(ylabel)
    plt.grid(axis="y", alpha=0.3)

    for bar, value in zip(bars, values):
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height(),
            f"{value:.2f}",
            ha="center",
            va="bottom",
            fontsize=11,
        )

    plt.tight_layout()

    output_file = RESULTS_DIR / filename

    plt.savefig(output_file, dpi=300)
    plt.close()

    print(f"Создан график: {output_file}")


def create_timeseries_chart():
    """Сравнивает изменение показателей во времени."""

    files = {
        "Адаптивное": RESULTS_DIR / "adaptive_timeseries.csv",
        "Фиксированное": RESULTS_DIR / "fixed_timeseries.csv",
    }

    datasets = {}

    for label, file_path in files.items():
        if not file_path.exists():
            print(f"Временной ряд не найден: {file_path}")
            return

        rows = []

        with open(file_path, "r", encoding="utf-8-sig") as file:
            rows = list(csv.DictReader(file))

        datasets[label] = rows

    charts = [
        ("queue_length", "Длина очереди", "Количество автомобилей",
         "comparison_queue_timeseries.png"),
        ("average_speed", "Средняя скорость", "м/с",
         "comparison_speed_timeseries.png"),
        ("waiting_vehicles", "Ожидающие автомобили", "Количество автомобилей",
         "comparison_waiting_timeseries.png"),
    ]

    for metric, title, ylabel, filename in charts:
        plt.figure(figsize=(12, 6))

        for label, rows in datasets.items():
            times = [float(row["time"]) / 60 for row in rows]
            values = [float(row[metric]) for row in rows]

            plt.plot(times, values, label=label, linewidth=1.2)

        plt.title(title)
        plt.xlabel("Время симуляции, мин")
        plt.ylabel(ylabel)
        plt.legend()
        plt.grid(alpha=0.3)
        plt.tight_layout()

        plt.savefig(RESULTS_DIR / filename, dpi=300)
        plt.close()

        print(f"Создан график: {filename}")


def main():
    print("=" * 55)
    print("СРАВНЕНИЕ АДАПТИВНОГО И ФИКСИРОВАННОГО УПРАВЛЕНИЯ")
    print("=" * 55)

    RESULTS_DIR.mkdir(exist_ok=True)

    adaptive = load_summary(ADAPTIVE_FILE)
    fixed = load_summary(FIXED_FILE)

    improvements = calculate_improvement(adaptive, fixed)

    print("\nРЕЗУЛЬТАТЫ СРАВНЕНИЯ:\n")

    for metric, improvement in improvements.items():
        print(f"{metric}: {improvement:+.2f}%")

    save_comparison_csv(adaptive, fixed, improvements)

    create_comparison_chart(
        adaptive, fixed,
        "average_queue_length",
        "Сравнение средней длины очереди",
        "Количество автомобилей",
        "comparison_queue.png",
    )

    create_comparison_chart(
        adaptive, fixed,
        "total_waiting_time_vehicle_seconds",
        "Сравнение суммарного времени ожидания",
        "Автомобиле-секунды",
        "comparison_waiting_time.png",
    )

    create_comparison_chart(
        adaptive, fixed,
        "average_speed_km_per_hour",
        "Сравнение средней скорости",
        "Скорость, км/ч",
        "comparison_speed.png",
    )

    create_timeseries_chart()

    print("\n" + "=" * 55)
    print("СРАВНИТЕЛЬНЫЙ АНАЛИЗ ЗАВЕРШЁН!")
    print("=" * 55)


if __name__ == "__main__":
    main()