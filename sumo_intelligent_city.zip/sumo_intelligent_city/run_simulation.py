import sys
import traci

from pathlib import Path

from src.traffic_agent import TrafficLightAgent
from src.statistics import TrafficStatistics
from src.fixed_controller import FixedController


# ==========================================
# НАСТРОЙКИ ПО УМОЛЧАНИЮ
# ==========================================

PROJECT_DIR = Path(__file__).resolve().parent

NETWORK_FILE = PROJECT_DIR / "network" / "city.net.xml"
ROUTES_FILE = PROJECT_DIR / "routes" / "city.rou.xml"

SIMULATION_TIME = 3600
STEP_LENGTH = 1.0
RANDOM_SEED = 42

USE_GUI = True
CONTROL_MODE = "adaptive"


# ==========================================
# ПОИСК SUMO
# ==========================================

def get_sumo_binary(use_gui):

    if use_gui:
        return "sumo-gui"

    return "sumo"


# ==========================================
# СОЗДАНИЕ АГЕНТОВ
# ==========================================

def create_agents():

    agents = {}

    traffic_lights = traci.trafficlight.getIDList()

    print("\nОбнаружены светофоры:")

    for tls_id in traffic_lights:

        agent = TrafficLightAgent(traci, tls_id)

        if agent.phases:
            agents[tls_id] = agent

            print(
                f"[AGENT] {tls_id}: "
                f"доступно фаз: {len(agent.phases)}"
            )
        else:
            print(
                f"[WARNING] {tls_id}: "
                "не удалось найти допустимые фазы"
            )

    print(f"\nВсего создано агентов: {len(agents)}")

    return agents


# ==========================================
# СТАТИСТИКА В КОНСОЛИ
# ==========================================

def show_statistics(agents):

    total_switches = sum(
        agent.switches
        for agent in agents.values()
    )

    print("\n========== СТАТИСТИКА ==========")
    print("Количество агентов:", len(agents))
    print("Количество переключений:", total_switches)
    print("Количество автомобилей:", traci.vehicle.getIDCount())

    print(
        "Ожидающих автомобилей:",
        sum(
            traci.lane.getLastStepHaltingNumber(lane_id)
            for lane_id in traci.lane.getIDList()
            if not lane_id.startswith(":")
        )
    )

    print("================================")

    return total_switches


# ==========================================
# ЗАПУСК СИМУЛЯЦИИ
# ==========================================

def run_simulation(
    control_mode=None,
    seed=None,
    route_file=None,
    output_dir=None,
    use_gui=None
):

    control_mode = control_mode or CONTROL_MODE
    seed = RANDOM_SEED if seed is None else seed
    route_file = Path(route_file) if route_file else ROUTES_FILE
    output_dir = Path(output_dir) if output_dir else PROJECT_DIR / "results"
    use_gui = USE_GUI if use_gui is None else use_gui

    if control_mode not in ("adaptive", "fixed"):
        raise ValueError(f"Неизвестный режим: {control_mode}")

    if not NETWORK_FILE.exists():
        raise FileNotFoundError(
            f"Не найдена сеть: {NETWORK_FILE}"
        )

    if not route_file.exists():
        raise FileNotFoundError(
            f"Не найдены маршруты: {route_file}"
        )

    output_dir.mkdir(parents=True, exist_ok=True)

    sumo_binary = get_sumo_binary(use_gui)

    sumo_cmd = [
        sumo_binary,

        "-n",
        str(NETWORK_FILE),

        "-r",
        str(route_file),

        "--begin",
        "0",

        "--end",
        str(SIMULATION_TIME),

        "--step-length",
        str(STEP_LENGTH),

        "--seed",
        str(seed),

        "--no-step-log",
        "true",

        "--time-to-teleport",
        "300"
    ]

    print("\n================================")
    print(" INTELLIGENT CITY SIMULATION")
    print("================================")
    print(f"Режим управления: {control_mode}")
    print(f"Seed: {seed}")
    print(f"Маршруты: {route_file}")
    print(f"Результаты: {output_dir}")

    print("\nЗапуск SUMO...")

    traci.start(sumo_cmd)

    total_switches = 0

    try:

        agents = {}
        fixed_controller = None

        if control_mode == "adaptive":
            agents = create_agents()

        elif control_mode == "fixed":
            fixed_controller = FixedController()

        statistics = TrafficStatistics(
            output_dir=output_dir,
            step_length=STEP_LENGTH
        )

        print("\nСимуляция запущена!\n")

        while traci.simulation.getTime() < SIMULATION_TIME:

            traci.simulationStep()

            if control_mode == "adaptive":

                for agent in agents.values():
                    agent.update()

            else:
                fixed_controller.update()

            statistics.collect()

            current_time = traci.simulation.getTime()

            if int(current_time) % 300 == 0:

                print(
                    f"Время: {int(current_time)} сек | "
                    f"Автомобилей: {traci.vehicle.getIDCount()}"
                )

            if traci.simulation.getMinExpectedNumber() == 0:
                break

        print("\nСимуляция завершена!")

        statistics.save()

        total_switches = show_statistics(agents)

    finally:
        traci.close()

    return total_switches


# ==========================================
# ОБЫЧНЫЙ ЗАПУСК
# ==========================================

if __name__ == "__main__":

    try:
        run_simulation()

    except Exception as error:

        print("\nОШИБКА СИМУЛЯЦИИ:")
        print(error)

        if traci.isLoaded():
            traci.close()

        sys.exit(1)