import traci


class FixedController:
    """Контроллер, использующий стандартные программы SUMO."""

    def __init__(self):
        self.traffic_lights = traci.trafficlight.getIDList()

        for tls_id in self.traffic_lights:
            # Возвращаем стандартную программу светофора SUMO
            traci.trafficlight.setProgram(tls_id, "0")

        print(
            f"[FIXED] Запущено фиксированное управление: "
            f"{len(self.traffic_lights)} светофоров"
        )

    def update(self):
        """
        Ничего не переключаем вручную.
        SUMO самостоятельно выполняет заданные циклы.
        """
        pass