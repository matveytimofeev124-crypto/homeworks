from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from src import config


@dataclass
class GreenPhase:

    state: str
    phase_index: int
    incoming_lanes: Tuple[str, ...]


class TrafficLightAgent:

    def __init__(self, traci, tls_id):

        self.traci = traci
        self.tls_id = tls_id

        self.controlled_links = (
            traci.trafficlight.getControlledLinks(tls_id)
        )

        self.signal_count = len(self.controlled_links)

        self.phases = self._discover_green_phases()

        self.current_state = (
            traci.trafficlight.getRedYellowGreenState(tls_id)
        )

        self.current_phase = self._phase_for_state(
            self.current_state
        )

        self.green_started = traci.simulation.getTime()

        self.last_decision = self.green_started

        self.pending_phase = None

        self.transition_until = 0.0

        self.phase_last_served = {
            phase.phase_index: self.green_started
            for phase in self.phases
        }

        self.switches = 0

    # --------------------------------------
    # Поиск безопасных зелёных фаз
    # --------------------------------------

    def _discover_green_phases(self):

        result = []

        logics = (
            self.traci.trafficlight.getAllProgramLogics(
                self.tls_id
            )
        )

        if not logics:
            return result

        active_program = (
            self.traci.trafficlight.getProgram(
                self.tls_id
            )
        )

        logic = next(
            (
                item for item in logics
                if item.programID == active_program
            ),
            logics[0]
        )

        seen = set()

        for index, phase in enumerate(logic.phases):

            state = phase.state

            if len(state) != self.signal_count:
                continue

            if not any(c in "Gg" for c in state):
                continue

            if any(c in "yY" for c in state):
                continue

            if state in seen:
                continue

            seen.add(state)

            green_indices = [
                i for i, c in enumerate(state)
                if c in "Gg"
            ]

            lanes = []

            for signal_index in green_indices:

                if signal_index >= len(self.controlled_links):
                    continue

                for link in self.controlled_links[signal_index]:

                    if link and link[0] not in lanes:
                        lanes.append(link[0])

            if lanes:

                result.append(
                    GreenPhase(
                        state=state,
                        phase_index=index,
                        incoming_lanes=tuple(lanes)
                    )
                )

        return result

    # --------------------------------------
    # Определение текущей фазы
    # --------------------------------------

    def _phase_for_state(self, state):

        for phase in self.phases:

            if phase.state == state:
                return phase

        return None

    # --------------------------------------
    # Подсчёт очереди
    # --------------------------------------

    def get_queue_length(self, phase):

        queue = 0

        for lane_id in phase.incoming_lanes:

            try:

                vehicles = (
                    self.traci.lane.getLastStepVehicleIDs(
                        lane_id
                    )
                )

                for vehicle_id in vehicles:

                    speed = (
                        self.traci.vehicle.getSpeed(
                            vehicle_id
                        )
                    )

                    if speed <= config.QUEUE_SPEED_THRESHOLD:
                        queue += 1

            except Exception:
                continue

        return queue

    # --------------------------------------
    # Оценка приоритета фазы
    # --------------------------------------

    def calculate_score(self, phase, now):

        queue = self.get_queue_length(phase)

        last_served = self.phase_last_served.get(
            phase.phase_index,
            self.green_started
        )

        waiting_time = max(
            0.0,
            now - last_served
        )

        score = (
            config.QUEUE_WEIGHT * queue
            +
            config.WAITING_WEIGHT * waiting_time
        )

        return score

    # --------------------------------------
    # Переключение на жёлтый
    # --------------------------------------

    def begin_switch(self, target, now):

        current_state = (
            self.traci.trafficlight.getRedYellowGreenState(
                self.tls_id
            )
        )

        yellow_state = "".join(
            "y" if signal in "Gg" else signal
            for signal in current_state
        )

        self.traci.trafficlight.setRedYellowGreenState(
            self.tls_id,
            yellow_state
        )

        self.pending_phase = target

        self.transition_until = (
            now + config.YELLOW_TIME
        )

        self.switches += 1

    # --------------------------------------
    # Основной цикл работы агента
    # --------------------------------------

    def update(self):

        now = self.traci.simulation.getTime()

        # Завершение жёлтого перехода
        if self.pending_phase is not None:

            if now >= self.transition_until:

                target = self.pending_phase

                self.traci.trafficlight.setRedYellowGreenState(
                    self.tls_id,
                    target.state
                )

                self.current_state = target.state

                self.current_phase = target

                self.phase_last_served[
                    target.phase_index
                ] = now

                self.green_started = now

                self.last_decision = now

                self.pending_phase = None

            return

        if not self.phases:
            return

        if (
            now - self.last_decision
            < config.DECISION_INTERVAL
        ):
            return

        self.last_decision = now

        if self.current_phase is None:

            best_phase = max(
                self.phases,
                key=lambda phase: self.calculate_score(
                    phase, now
                )
            )

            self.begin_switch(best_phase, now)

            return

        green_duration = now - self.green_started

        if green_duration < config.MIN_GREEN:
            return

        scored_phases = [
            (
                self.calculate_score(phase, now),
                phase
            )
            for phase in self.phases
        ]

        scored_phases.sort(
            key=lambda item: item[0],
            reverse=True
        )

        best_score, best_phase = scored_phases[0]

        current_score = self.calculate_score(
            self.current_phase,
            now
        )

        should_switch = (
            best_phase.state != self.current_phase.state
            and (
                green_duration >= config.MAX_GREEN
                or best_score > (
                    current_score + config.SWITCH_MARGIN
                )
            )
        )

        if should_switch:

            self.begin_switch(
                best_phase,
                now
            )