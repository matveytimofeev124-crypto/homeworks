import csv
from pathlib import Path

import traci


class TrafficStatistics:
    """Сбор статистики транспортного потока во время симуляции."""

    def __init__(self, output_dir, step_length=1.0):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.step_length = step_length
        self.records = []

        self.total_waiting_time = 0.0
        self.total_queue_length = 0.0
        self.total_speed = 0.0
        self.speed_samples = 0
        self.total_vehicle_samples = 0
        self.total_arrived = 0
        self.total_departed = 0

        # Накопленное время ожидания каждого автомобиля
        self.vehicle_waiting = {}

    def collect(self):
        """Собирает показатели за текущий шаг симуляции."""

        current_time = traci.simulation.getTime()
        vehicle_ids = traci.vehicle.getIDList()

        vehicle_count = len(vehicle_ids)
        waiting_vehicles = 0
        step_waiting_time = 0.0
        step_speed_sum = 0.0

        for vehicle_id in vehicle_ids:
            speed = traci.vehicle.getSpeed(vehicle_id)

            # Автомобиль считается ожидающим, если почти не движется
            if speed < 0.1:
                waiting_vehicles += 1
                step_waiting_time += self.step_length

                self.vehicle_waiting[vehicle_id] = (
                    self.vehicle_waiting.get(vehicle_id, 0.0)
                    + self.step_length
                )
            else:
                self.vehicle_waiting.setdefault(vehicle_id, 0.0)

            step_speed_sum += speed

        # Суммарная длина очередей на обычных дорожных полосах
        queue_length = 0

        for lane_id in traci.lane.getIDList():
            if lane_id.startswith(":"):
                continue

            queue_length += traci.lane.getLastStepHaltingNumber(lane_id)

        average_speed = (
            step_speed_sum / vehicle_count if vehicle_count > 0 else 0.0
        )

        # Сохраняем показатели текущего шага
        self.records.append({
            "time": current_time,
            "vehicles": vehicle_count,
            "waiting_vehicles": waiting_vehicles,
            "queue_length": queue_length,
            "average_speed": average_speed,
            "waiting_time_step": step_waiting_time,
            "arrived_step": traci.simulation.getArrivedNumber(),
            "departed_step": traci.simulation.getDepartedNumber(),
        })

        self.total_waiting_time += step_waiting_time
        self.total_queue_length += queue_length
        self.total_speed += step_speed_sum
        self.speed_samples += vehicle_count
        self.total_vehicle_samples += vehicle_count

        self.total_arrived += traci.simulation.getArrivedNumber()
        self.total_departed += traci.simulation.getDepartedNumber()

    def save(self):
        """Сохраняет временные ряды и итоговую статистику в CSV."""

        timeseries_file = self.output_dir / "traffic_timeseries.csv"

        if self.records:
            with open(timeseries_file, "w", newline="", encoding="utf-8-sig") as file:
                writer = csv.DictWriter(
                    file,
                    fieldnames=self.records[0].keys()
                )
                writer.writeheader()
                writer.writerows(self.records)

        steps = len(self.records)

        average_queue = (
            self.total_queue_length / steps if steps else 0.0
        )

        average_speed = (
            self.total_speed / self.speed_samples
            if self.speed_samples else 0.0
        )

        average_waiting_vehicles = (
            sum(record["waiting_vehicles"] for record in self.records) / steps
            if steps else 0.0
        )

        summary = {
            "simulation_time_seconds": (
                self.records[-1]["time"] if self.records else 0
            ),
            "arrived_vehicles": self.total_arrived,
            "departed_vehicles": self.total_departed,
            "average_queue_length": average_queue,
            "average_waiting_vehicles": average_waiting_vehicles,
            "total_waiting_time_vehicle_seconds": self.total_waiting_time,
            "average_speed_m_per_second": average_speed,
            "average_speed_km_per_hour": average_speed * 3.6,
            "vehicles_at_end": (
                self.records[-1]["vehicles"] if self.records else 0
            ),
        }

        summary_file = self.output_dir / "traffic_summary.csv"

        with open(summary_file, "w", newline="", encoding="utf-8-sig") as file:
            writer = csv.writer(file)
            writer.writerow(["metric", "value"])
            writer.writerows(summary.items())

        print("\n========== СОБРАННАЯ СТАТИСТИКА ==========")
        for metric, value in summary.items():
            print(f"{metric}: {value:.2f}" if isinstance(value, float)
                  else f"{metric}: {value}")

        print("\nФайлы сохранены:")
        print(timeseries_file)
        print(summary_file)

        return summary