from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt

PROJECT_DIR = Path(__file__).resolve().parent
RESULTS_DIR = PROJECT_DIR / "results"

DATA_FILE = RESULTS_DIR / "adaptive_timeseries.csv"

if not DATA_FILE.exists():
    raise FileNotFoundError(
        f"Не найден файл: {DATA_FILE}\n"
        "Проверь, что traffic_timeseries.csv переименован "
        "в adaptive_timeseries.csv"
    )

df = pd.read_csv(DATA_FILE)

# 1. Изменение количества автомобилей
plt.figure(figsize=(10, 5))
plt.plot(df["time"], df["vehicles"])
plt.title("Количество автомобилей в городской сети")
plt.xlabel("Время симуляции, секунды")
plt.ylabel("Количество автомобилей")
plt.grid(True)
plt.tight_layout()
plt.savefig(RESULTS_DIR / "adaptive_vehicles.png", dpi=300)
plt.show()

# 2. Изменение длины очередей
plt.figure(figsize=(10, 5))
plt.plot(df["time"], df["queue_length"])
plt.title("Динамика транспортных очередей")
plt.xlabel("Время симуляции, секунды")
plt.ylabel("Количество автомобилей в очередях")
plt.grid(True)
plt.tight_layout()
plt.savefig(RESULTS_DIR / "adaptive_queues.png", dpi=300)
plt.show()

# 3. Изменение средней скорости
plt.figure(figsize=(10, 5))
plt.plot(df["time"], df["average_speed"] * 3.6)
plt.title("Средняя скорость транспортного потока")
plt.xlabel("Время симуляции, секунды")
plt.ylabel("Скорость, км/ч")
plt.grid(True)
plt.tight_layout()
plt.savefig(RESULTS_DIR / "adaptive_speed.png", dpi=300)
plt.show()

# 4. Количество ожидающих автомобилей
plt.figure(figsize=(10, 5))
plt.plot(df["time"], df["waiting_vehicles"])
plt.title("Количество ожидающих автомобилей")
plt.xlabel("Время симуляции, секунды")
plt.ylabel("Количество автомобилей")
plt.grid(True)
plt.tight_layout()
plt.savefig(RESULTS_DIR / "adaptive_waiting.png", dpi=300)
plt.show()

print("Графики успешно сохранены в папке results!")