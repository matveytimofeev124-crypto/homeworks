import csv
from pathlib import Path
from statistics import mean, stdev


PROJECT_DIR = Path(__file__).resolve().parent

EXPERIMENTS_DIR = (
    PROJECT_DIR / "results" / "experiments"
)

SEEDS = [42, 43, 44, 45, 46]

MODES = ["adaptive", "fixed"]

METRICS = [
    "simulation_time_seconds",
    "arrived_vehicles",
    "departed_vehicles",
    "average_queue_length",
    "average_waiting_vehicles",
    "total_waiting_time_vehicle_seconds",
    "average_speed_m_per_second",
    "average_speed_km_per_hour",
    "vehicles_at_end"
]


# ==========================================
# ЧТЕНИЕ CSV ФОРМАТА metric,value
# ==========================================

def read_summary(path):

    result = {}

    with open(
        path,
        "r",
        encoding="utf-8-sig",
        newline=""
    ) as file:

        reader = csv.DictReader(file)

        for row in reader:

            metric = row["metric"]
            value = float(row["value"])

            result[metric] = value

    return result


# ==========================================
# СОХРАНЕНИЕ CSV
# ==========================================

def save_csv(rows, path):

    if not rows:
        print(f"[WARNING] Нет данных для {path.name}")
        return

    with open(
        path,
        "w",
        encoding="utf-8-sig",
        newline=""
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=list(rows[0].keys())
        )

        writer.writeheader()
        writer.writerows(rows)

    print(f"[OK] Создан файл: {path}")


# ==========================================
# СБОР РЕЗУЛЬТАТОВ ВСЕХ ЗАПУСКОВ
# ==========================================

def collect_results():

    results = []

    for seed in SEEDS:

        for mode in MODES:

            summary_file = (
                EXPERIMENTS_DIR
                / mode
                / f"seed_{seed}"
                / "traffic_summary.csv"
            )

            if not summary_file.exists():

                print(
                    f"[WARNING] Не найден: {summary_file}"
                )

                continue

            metrics = read_summary(summary_file)

            row = {
                "seed": seed,
                "control_mode": mode
            }

            for metric in METRICS:

                if metric not in metrics:

                    raise ValueError(
                        f"Показатель {metric} отсутствует "
                        f"в файле {summary_file}"
                    )

                row[metric] = metrics[metric]

            results.append(row)

            print(
                f"[OK] Загружен {mode}, seed={seed}"
            )

    return results


# ==========================================
# СРЕДНИЕ ЗНАЧЕНИЯ И СТАНДАРТНОЕ ОТКЛОНЕНИЕ
# ==========================================

def calculate_aggregate(results):

    aggregate = []

    for mode in MODES:

        mode_results = [
            row for row in results
            if row["control_mode"] == mode
        ]

        for metric in METRICS:

            values = [
                row[metric]
                for row in mode_results
            ]

            if not values:
                continue

            aggregate.append({
                "control_mode": mode,
                "metric": metric,
                "mean": mean(values),
                "std": (
                    stdev(values)
                    if len(values) > 1
                    else 0.0
                ),
                "runs": len(values)
            })

    return aggregate


# ==========================================
# ПАРНОЕ СРАВНЕНИЕ ADAPTIVE VS FIXED
# ==========================================

def calculate_improvements(results):

    metrics = [
        "average_queue_length",
        "average_waiting_vehicles",
        "total_waiting_time_vehicle_seconds",
        "average_speed_km_per_hour",
        "arrived_vehicles"
    ]

    improvements = []

    for metric in metrics:

        differences = []

        for seed in SEEDS:

            adaptive = next(
                (
                    row for row in results
                    if row["seed"] == seed
                    and row["control_mode"] == "adaptive"
                ),
                None
            )

            fixed = next(
                (
                    row for row in results
                    if row["seed"] == seed
                    and row["control_mode"] == "fixed"
                ),
                None
            )

            if adaptive is None or fixed is None:
                continue

            a = adaptive[metric]
            f = fixed[metric]

            if f == 0:
                continue

            if metric in (
                "average_speed_km_per_hour",
                "arrived_vehicles"
            ):
                improvement = (a - f) / abs(f) * 100
            else:
                improvement = (f - a) / abs(f) * 100

            differences.append(improvement)

        if differences:

            improvements.append({
                "metric": metric,
                "mean_improvement_percent": mean(differences),
                "std_improvement_percent": (
                    stdev(differences)
                    if len(differences) > 1
                    else 0.0
                ),
                "paired_runs": len(differences)
            })

    return improvements


# ==========================================
# MAIN
# ==========================================

def main():

    print("=" * 60)
    print("ВОССТАНОВЛЕНИЕ ОТЧЁТОВ ЭКСПЕРИМЕНТОВ")
    print("=" * 60)

    results = collect_results()

    print(f"\nУспешно загружено запусков: {len(results)}")

    save_csv(
        results,
        EXPERIMENTS_DIR / "experiment_summary.csv"
    )

    aggregate = calculate_aggregate(results)

    save_csv(
        aggregate,
        EXPERIMENTS_DIR / "experiment_aggregate.csv"
    )

    improvements = calculate_improvements(results)

    save_csv(
        improvements,
        EXPERIMENTS_DIR / "paired_improvements.csv"
    )

    print("\nСРЕДНЕЕ ПАРНОЕ УЛУЧШЕНИЕ ADAPTIVE:")

    for item in improvements:

        print(
            f"{item['metric']}: "
            f"{item['mean_improvement_percent']:+.2f}% "
            f"(пар: {item['paired_runs']})"
        )

    print("\nРабота завершена.")


if __name__ == "__main__":
    main()