import csv
import sys
import traceback
from pathlib import Path
from statistics import mean, stdev

import prepare
from run_simulation import run_simulation


# ==========================================
# НАСТРОЙКИ ЭКСПЕРИМЕНТА
# ==========================================

PROJECT_DIR = Path(__file__).resolve().parent

SEEDS = [42, 43, 44, 45, 46]

CONTROL_MODES = ["adaptive", "fixed"]

EXPERIMENTS_DIR = PROJECT_DIR / "results" / "experiments"
ROUTES_EXPERIMENTS_DIR = PROJECT_DIR / "routes" / "experiments"

USE_GUI = False


# ==========================================
# ГЕНЕРАЦИЯ МАРШРУТОВ
# ==========================================

def generate_experiment_routes(seed):

    route_file = (
        ROUTES_EXPERIMENTS_DIR
        / f"routes_seed_{seed}.rou.xml"
    )

    print("\n" + "=" * 60)
    print(f"ГЕНЕРАЦИЯ МАРШРУТОВ: SEED {seed}")
    print("=" * 60)

    prepare.generate_routes(
        seed=seed,
        routes_file=route_file
    )

    return route_file


# ==========================================
# ЧТЕНИЕ ИТОГОВОЙ СТАТИСТИКИ
# ==========================================

def read_summary(summary_file):

    if not summary_file.exists():
        raise FileNotFoundError(
            f"Не найден файл статистики: {summary_file}"
        )

    with open(
        summary_file,
        "r",
        encoding="utf-8-sig",
        newline=""
    ) as file:

        reader = csv.DictReader(file)
        rows = list(reader)

    if not rows:
        raise ValueError(
            f"Файл статистики пуст: {summary_file}"
        )

    result = {}

    for key, value in rows[0].items():

        try:
            result[key] = float(value)
        except (ValueError, TypeError):
            result[key] = value

    return result


# ==========================================
# ОДИН ЭКСПЕРИМЕНТ
# ==========================================

def run_one_experiment(seed, mode, route_file):

    output_dir = (
        EXPERIMENTS_DIR
        / mode
        / f"seed_{seed}"
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    print("\n" + "#" * 60)
    print(f"ЭКСПЕРИМЕНТ: {mode.upper()} | SEED {seed}")
    print("#" * 60)

    switches = run_simulation(
        control_mode=mode,
        seed=seed,
        route_file=route_file,
        output_dir=output_dir,
        use_gui=USE_GUI
    )

    summary_file = output_dir / "traffic_summary.csv"

    summary = read_summary(summary_file)

    summary["seed"] = seed
    summary["control_mode"] = mode
    summary["switches"] = switches

    print(f"\n[OK] Эксперимент {mode}, seed={seed} завершён.")

    return summary


# ==========================================
# СОХРАНЕНИЕ ОБЩЕЙ ТАБЛИЦЫ
# ==========================================

def save_csv(rows, output_file):

    if not rows:
        return

    output_file.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    fieldnames = list(rows[0].keys())

    with open(
        output_file,
        "w",
        encoding="utf-8-sig",
        newline=""
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames
        )

        writer.writeheader()
        writer.writerows(rows)

    print(f"[OK] Сохранён файл: {output_file}")


# ==========================================
# СРЕДНИЕ ЗНАЧЕНИЯ И УЛУЧШЕНИЯ
# ==========================================

def calculate_aggregate(rows):

    metrics = [
        "average_queue_length",
        "average_waiting_vehicles",
        "total_waiting_time_vehicle_seconds",
        "average_speed_km_per_hour",
        "arrived_vehicles",
        "vehicles_at_end"
    ]

    aggregate_rows = []

    for mode in CONTROL_MODES:

        mode_rows = [
            row for row in rows
            if row["control_mode"] == mode
        ]

        if not mode_rows:
            continue

        for metric in metrics:

            values = [
                float(row[metric])
                for row in mode_rows
                if metric in row
                and isinstance(row[metric], (int, float))
            ]

            if not values:
                continue

            aggregate_rows.append({
                "control_mode": mode,
                "metric": metric,
                "mean": mean(values),
                "std": stdev(values) if len(values) > 1 else 0.0,
                "runs": len(values)
            })

    return aggregate_rows


def calculate_paired_improvements(rows):

    metrics = [
        "average_queue_length",
        "average_waiting_vehicles",
        "total_waiting_time_vehicle_seconds",
        "average_speed_km_per_hour",
        "arrived_vehicles"
    ]

    results = []

    for metric in metrics:

        improvements = []

        for seed in SEEDS:

            adaptive = next(
                (
                    row for row in rows
                    if row["seed"] == seed
                    and row["control_mode"] == "adaptive"
                ),
                None
            )

            fixed = next(
                (
                    row for row in rows
                    if row["seed"] == seed
                    and row["control_mode"] == "fixed"
                ),
                None
            )

            if adaptive is None or fixed is None:
                continue

            adaptive_value = float(adaptive[metric])
            fixed_value = float(fixed[metric])

            if fixed_value == 0:
                continue

            if metric == "average_speed_km_per_hour":
                improvement = (
                    (adaptive_value - fixed_value)
                    / abs(fixed_value)
                ) * 100
            else:
                improvement = (
                    (fixed_value - adaptive_value)
                    / abs(fixed_value)
                ) * 100

            improvements.append(improvement)

        if improvements:

            results.append({
                "metric": metric,
                "mean_improvement_percent": mean(improvements),
                "std_improvement_percent": (
                    stdev(improvements)
                    if len(improvements) > 1
                    else 0.0
                ),
                "paired_runs": len(improvements)
            })

    return results


# ==========================================
# ОСНОВНОЙ ЗАПУСК ЭКСПЕРИМЕНТОВ
# ==========================================

def main():

    print("=" * 60)
    print(" MULTI-SEED TRAFFIC CONTROL EXPERIMENTS")
    print("=" * 60)

    print(f"Seeds: {SEEDS}")
    print(f"Режимы: {CONTROL_MODES}")
    print(f"Всего запусков: {len(SEEDS) * len(CONTROL_MODES)}")

    if not prepare.NETWORK_FILE.exists():

        raise FileNotFoundError(
            "Не найдена городская сеть. "
            "Сначала выполните python prepare.py"
        )

    EXPERIMENTS_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    ROUTES_EXPERIMENTS_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    all_results = []

    failed_runs = []

    for seed in SEEDS:

        # Один набор маршрутов для обоих контроллеров
        route_file = generate_experiment_routes(seed)

        for mode in CONTROL_MODES:

            try:

                result = run_one_experiment(
                    seed=seed,
                    mode=mode,
                    route_file=route_file
                )

                all_results.append(result)

            except Exception as error:

                print("\n[ERROR] Эксперимент завершился с ошибкой:")
                print(f"Режим: {mode}")
                print(f"Seed: {seed}")
                print(error)

                traceback.print_exc()

                failed_runs.append({
                    "seed": seed,
                    "control_mode": mode,
                    "error": str(error)
                })

    # ======================================
    # СОХРАНЕНИЕ РЕЗУЛЬТАТОВ
    # ======================================

    save_csv(
        all_results,
        EXPERIMENTS_DIR / "experiment_summary.csv"
    )

    aggregate = calculate_aggregate(all_results)

    save_csv(
        aggregate,
        EXPERIMENTS_DIR / "experiment_aggregate.csv"
    )

    improvements = calculate_paired_improvements(all_results)

    save_csv(
        improvements,
        EXPERIMENTS_DIR / "paired_improvements.csv"
    )

    if failed_runs:

        save_csv(
            failed_runs,
            EXPERIMENTS_DIR / "failed_runs.csv"
        )

    # ======================================
    # ИТОГОВЫЙ ОТЧЁТ
    # ======================================

    print("\n" + "=" * 60)
    print("ЭКСПЕРИМЕНТЫ ЗАВЕРШЕНЫ")
    print("=" * 60)

    print(f"Успешных запусков: {len(all_results)}")
    print(f"Ошибок: {len(failed_runs)}")

    print("\nСреднее парное улучшение адаптивного управления:")

    for item in improvements:

        print(
            f"{item['metric']}: "
            f"{item['mean_improvement_percent']:+.2f}%"
        )

    print("\nРезультаты сохранены в:")
    print(EXPERIMENTS_DIR)


if __name__ == "__main__":

    try:
        main()

    except Exception as error:

        print("\nКРИТИЧЕСКАЯ ОШИБКА:")
        print(error)

        sys.exit(1)