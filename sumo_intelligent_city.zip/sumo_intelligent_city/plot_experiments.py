import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


# ==========================================
# НАСТРОЙКИ
# ==========================================

PROJECT_DIR = Path(__file__).resolve().parent

RESULTS_DIR = PROJECT_DIR / "results" / "experiments"
GRAPHS_DIR = RESULTS_DIR / "graphs"

SEEDS = [42, 43, 44, 45, 46]

MODES = ["adaptive", "fixed"]

COLORS = {
    "adaptive": "#2196F3",
    "fixed": "#FF9800"
}

LABELS = {
    "adaptive": "Адаптивное управление",
    "fixed": "Фиксированное управление"
}

# Шрифт с поддержкой кириллицы
plt.rcParams["font.family"] = "DejaVu Sans"
plt.rcParams["font.size"] = 10
plt.rcParams["axes.titlesize"] = 13
plt.rcParams["axes.labelsize"] = 11
plt.rcParams["figure.figsize"] = (10, 6)
plt.rcParams["axes.grid"] = True
plt.rcParams["grid.alpha"] = 0.3


# ==========================================
# ЧТЕНИЕ CSV
# ==========================================

def read_csv(path):

    if not path.exists():
        raise FileNotFoundError(
            f"Не найден файл: {path}"
        )

    with open(
        path,
        "r",
        encoding="utf-8-sig",
        newline=""
    ) as file:

        return list(csv.DictReader(file))


def load_data():

    summary = read_csv(
        RESULTS_DIR / "experiment_summary.csv"
    )

    aggregate = read_csv(
        RESULTS_DIR / "experiment_aggregate.csv"
    )

    return summary, aggregate


# ==========================================
# ПОДГОТОВКА ПАПКИ
# ==========================================

def prepare_output():

    GRAPHS_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    print(f"[INFO] Папка графиков: {GRAPHS_DIR}")


# ==========================================
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ==========================================

def get_aggregate(aggregate, mode, metric):

    for row in aggregate:

        if (
            row["control_mode"] == mode
            and row["metric"] == metric
        ):

            return (
                float(row["mean"]),
                float(row["std"])
            )

    raise ValueError(
        f"Нет данных: {mode}, {metric}"
    )


def save_plot(filename):

    path = GRAPHS_DIR / filename

    plt.tight_layout()

    plt.savefig(
        path,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()

    print(f"[OK] Создан график: {path}")


# ==========================================
# 1. СРАВНЕНИЕ ДЛИНЫ ОЧЕРЕДЕЙ
# ==========================================

def plot_queue_comparison(aggregate):

    metric = "average_queue_length"

    values = [
        get_aggregate(aggregate, mode, metric)
        for mode in MODES
    ]

    means = [item[0] for item in values]
    stds = [item[1] for item in values]

    plt.figure()

    bars = plt.bar(
        [LABELS[m] for m in MODES],
        means,
        yerr=stds,
        capsize=7,
        color=[COLORS[m] for m in MODES],
        width=0.55
    )

    plt.title("Сравнение средней длины транспортных очередей")
    plt.ylabel("Средняя длина очереди")
    plt.xlabel("Алгоритм управления")

    for bar, value in zip(bars, means):

        plt.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height(),
            f"{value:.2f}",
            ha="center",
            va="bottom"
        )

    save_plot("mean_queue_comparison.png")


# ==========================================
# 2. СРАВНЕНИЕ ОЖИДАЮЩИХ АВТОМОБИЛЕЙ
# ==========================================

def plot_waiting_comparison(aggregate):

    metric = "average_waiting_vehicles"

    values = [
        get_aggregate(aggregate, mode, metric)
        for mode in MODES
    ]

    means = [item[0] for item in values]
    stds = [item[1] for item in values]

    plt.figure()

    bars = plt.bar(
        [LABELS[m] for m in MODES],
        means,
        yerr=stds,
        capsize=7,
        color=[COLORS[m] for m in MODES],
        width=0.55
    )

    plt.title("Сравнение среднего количества ожидающих автомобилей")
    plt.ylabel("Количество автомобилей")
    plt.xlabel("Алгоритм управления")

    for bar, value in zip(bars, means):

        plt.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height(),
            f"{value:.2f}",
            ha="center",
            va="bottom"
        )

    save_plot("mean_waiting_comparison.png")


# ==========================================
# 3. СРАВНЕНИЕ СРЕДНЕЙ СКОРОСТИ
# ==========================================

def plot_speed_comparison(aggregate):

    metric = "average_speed_km_per_hour"

    values = [
        get_aggregate(aggregate, mode, metric)
        for mode in MODES
    ]

    means = [item[0] for item in values]
    stds = [item[1] for item in values]

    plt.figure()

    bars = plt.bar(
        [LABELS[m] for m in MODES],
        means,
        yerr=stds,
        capsize=7,
        color=[COLORS[m] for m in MODES],
        width=0.55
    )

    plt.title("Сравнение средней скорости движения")
    plt.ylabel("Средняя скорость, км/ч")
    plt.xlabel("Алгоритм управления")

    for bar, value in zip(bars, means):

        plt.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height(),
            f"{value:.2f}",
            ha="center",
            va="bottom"
        )

    save_plot("mean_speed_comparison.png")


# ==========================================
# 4. УЛУЧШЕНИЕ ПО КАЖДОМУ SEED
# ==========================================

def plot_paired_improvements(summary):

    metrics = [
        ("average_queue_length", "Длина очереди"),
        ("average_waiting_vehicles", "Ожидающие автомобили"),
        ("average_speed_km_per_hour", "Средняя скорость"),
        ("arrived_vehicles", "Прибывшие автомобили")
    ]

    plt.figure(figsize=(11, 6))

    for metric, label in metrics:

        improvements = []

        for seed in SEEDS:

            adaptive = next(
                (
                    row for row in summary
                    if int(row["seed"]) == seed
                    and row["control_mode"] == "adaptive"
                ),
                None
            )

            fixed = next(
                (
                    row for row in summary
                    if int(row["seed"]) == seed
                    and row["control_mode"] == "fixed"
                ),
                None
            )

            if adaptive is None or fixed is None:
                raise ValueError(
                    f"Нет пары результатов для seed={seed}"
                )

            a = float(adaptive[metric])
            f = float(fixed[metric])

            if f == 0:
                raise ValueError(
                    f"Нулевое значение fixed: {metric}, seed={seed}"
                )

            if metric in (
                "average_speed_km_per_hour",
                "arrived_vehicles"
            ):
                improvement = (a - f) / abs(f) * 100
            else:
                improvement = (f - a) / abs(f) * 100

            improvements.append(improvement)

        plt.plot(
            SEEDS,
            improvements,
            marker="o",
            linewidth=2,
            label=label
        )

    plt.axhline(
        0,
        color="black",
        linewidth=1
    )

    plt.title("Улучшение адаптивного управления по каждому seed")
    plt.xlabel("Seed генератора случайных чисел")
    plt.ylabel("Улучшение относительно фиксированного управления, %")

    plt.xticks(SEEDS)
    plt.legend()

    save_plot("paired_improvements.png")


# ==========================================
# 5. УСТОЙЧИВОСТЬ РЕЗУЛЬТАТОВ
# ==========================================

def plot_results_variability(aggregate):

    metrics = [
        ("average_queue_length", "Длина очереди"),
        ("average_waiting_vehicles", "Ожидающие автомобили"),
        ("average_speed_km_per_hour", "Средняя скорость")
    ]

    x = np.arange(len(metrics))
    width = 0.35

    plt.figure(figsize=(10, 6))

    for index, mode in enumerate(MODES):

        coefficients = []

        for metric, _ in metrics:

            average, deviation = get_aggregate(
                aggregate,
                mode,
                metric
            )

            if average == 0:
                coefficient = 0
            else:
                coefficient = deviation / abs(average) * 100

            coefficients.append(coefficient)

        positions = x + (index - 0.5) * width

        bars = plt.bar(
            positions,
            coefficients,
            width,
            label=LABELS[mode],
            color=COLORS[mode]
        )

        for bar, value in zip(bars, coefficients):

            plt.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height(),
                f"{value:.2f}%",
                ha="center",
                va="bottom",
                fontsize=9
            )

    plt.title("Разброс результатов экспериментов")
    plt.ylabel("Коэффициент вариации, %")
    plt.xlabel("Показатель")

    plt.xticks(
        x,
        [label for _, label in metrics]
    )

    plt.legend()

    save_plot("results_variability.png")


# ==========================================
# MAIN
# ==========================================

def main():

    print("=" * 60)
    print("ПОСТРОЕНИЕ ГРАФИКОВ ЭКСПЕРИМЕНТОВ")
    print("=" * 60)

    prepare_output()

    summary, aggregate = load_data()

    print(f"[INFO] Загружено результатов: {len(summary)}")

    plot_queue_comparison(aggregate)

    plot_waiting_comparison(aggregate)

    plot_speed_comparison(aggregate)

    plot_paired_improvements(summary)

    plot_results_variability(aggregate)

    print("\n" + "=" * 60)
    print("ВСЕ ГРАФИКИ УСПЕШНО СОЗДАНЫ")
    print("=" * 60)

    print(f"Папка: {GRAPHS_DIR}")


if __name__ == "__main__":

    main()